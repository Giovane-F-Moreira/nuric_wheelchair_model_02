# API_Leaflet
O projeto baseia-se na utilização da API do Leaflet, bem como na API do MapBox.
