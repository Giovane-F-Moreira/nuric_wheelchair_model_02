#!/bin/bash
xdg-open ./index.html